# HTTP-Fortnite-Bot
Uses JavaScript to emulate a Fortnite client and can join parties through HTTP and change skins / emotes visually.

Requirements:
- Node.JS
- A working brain

Basic steps:
1) Download and unzip (ofc)
2) Run 'npm install'
3) Run the start file and enter a **BOT ACCOUNTS** details!

Report issues and be descriptive, if your asking for a tutorial there your ticket WILL be closed, There will be one posted on AquaPlay's youtube channel!
